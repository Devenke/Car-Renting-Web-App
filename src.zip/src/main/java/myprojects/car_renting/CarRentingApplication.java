package myprojects.car_renting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarRentingApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarRentingApplication.class, args);
	}

}
